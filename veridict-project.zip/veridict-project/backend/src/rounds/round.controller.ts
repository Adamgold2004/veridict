import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common';
import { RoundService } from './round.service';
import { CreateRoundDto } from './dto/create-round.dto';
import { UpdateRoundDto, AssignSpeakerDto, SwitchFormatDto } from './dto/update-round.dto';
import { AssignReplyDto, LogPoiDto } from './dto/reply-and-poi.dto';

@Controller('api/rounds')
export class RoundController {
  constructor(private readonly rounds: RoundService) {}

  @Post()
  create(@Body() dto: CreateRoundDto) {
    return this.rounds.create(dto);
  }

  @Get()
  list() {
    return this.rounds.list();
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.rounds.get(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateRoundDto) {
    return this.rounds.update(id, dto);
  }

  @Post(':id/speakers')
  assignSpeaker(@Param('id') id: string, @Body() dto: AssignSpeakerDto) {
    return this.rounds.assignSpeaker(id, dto);
  }

  @Post(':id/reply')
  assignReply(@Param('id') id: string, @Body() dto: AssignReplyDto) {
    return this.rounds.assignReply(id, dto);
  }

  @Post(':id/poi')
  logPoi(@Param('id') id: string, @Body() dto: LogPoiDto) {
    return this.rounds.logPoi(id, dto);
  }

  @Post(':id/switch-format')
  switchFormat(@Param('id') id: string, @Body() dto: SwitchFormatDto) {
    return this.rounds.switchFormat(id, dto);
  }

  @Post(':id/reopen')
  reopen(@Param('id') id: string) {
    return this.rounds.reopen(id);
  }
}
