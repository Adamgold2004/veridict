import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { FormatService } from '../formats/format.service';
import { CreateRoundDto } from './dto/create-round.dto';
import { UpdateRoundDto, AssignSpeakerDto, SwitchFormatDto } from './dto/update-round.dto';
import { AssignReplyDto, LogPoiDto } from './dto/reply-and-poi.dto';
import { nowIso, Round } from './round.entity';

@Injectable()
export class RoundService {
  private readonly rounds = new Map<string, Round>();

  constructor(private readonly formats: FormatService) {}

  create(dto: CreateRoundDto): Round {
    // Validates the formatId exists / throws 404 otherwise.
    this.formats.get(dto.formatId);

    const round: Round = {
      id: randomUUID(),
      formatId: dto.formatId,
      motion: dto.motion,
      roundName: dto.roundName,
      judgeName: dto.judgeName,
      status: 'draft',
      createdAt: nowIso(),
      updatedAt: nowIso(),
      speakers: {},
      replyAssignments: {},
      scores: {},
      reasonForDecision: '',
      lowPointWinConfirmed: false,
      poiLog: [],
      aiAcceptedFields: [],
    };
    this.rounds.set(round.id, round);
    return round;
  }

  get(id: string): Round {
    const round = this.rounds.get(id);
    if (!round) throw new NotFoundException(`Round "${id}" not found`);
    return round;
  }

  list(): Round[] {
    return Array.from(this.rounds.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  update(id: string, dto: UpdateRoundDto): Round {
    const round = this.get(id);
    if (round.status === 'submitted' && dto.status !== 'reopened') {
      throw new BadRequestException('Round is locked. Reopen it before editing.');
    }
    Object.assign(round, dto, { updatedAt: nowIso() });
    return round;
  }

  assignSpeaker(id: string, dto: AssignSpeakerDto): Round {
    const round = this.get(id);
    this.assertEditable(round);
    const format = this.formats.get(round.formatId);
    const role = format.roles.find((r) => r.id === dto.roleId);
    if (!role) {
      throw new BadRequestException(`Role "${dto.roleId}" does not exist in format "${round.formatId}"`);
    }
    round.speakers[dto.roleId] = dto.speakerName;
    round.updatedAt = nowIso();
    return round;
  }

  /**
   * §3.1 — a reply speech may only be assigned to a speaker who already
   * delivered a substantive speech for that side in this round.
   */
  assignReply(id: string, dto: AssignReplyDto): Round {
    const round = this.get(id);
    this.assertEditable(round);
    const format = this.formats.get(round.formatId);
    if (!format.hasReplySpeeches) {
      throw new BadRequestException(`Format "${format.id}" has no reply speeches.`);
    }
    const replyRole = format.roles.find((r) => r.id === dto.replyRoleId && r.isReply);
    if (!replyRole) {
      throw new BadRequestException(`"${dto.replyRoleId}" is not a valid reply role for format "${format.id}"`);
    }
    const deliveredRole = format.roles.find((r) => r.id === dto.deliveredByRoleId && !r.isReply);
    if (!deliveredRole) {
      throw new BadRequestException(`"${dto.deliveredByRoleId}" is not a valid substantive role for format "${format.id}"`);
    }
    if (deliveredRole.side !== replyRole.side) {
      throw new BadRequestException(
        `Reply "${replyRole.id}" belongs to side "${replyRole.side}" but "${dto.deliveredByRoleId}" spoke for side "${deliveredRole.side}". A speaker may only give the reply for their own side.`,
      );
    }
    if (!round.speakers[dto.deliveredByRoleId]) {
      throw new BadRequestException(
        `No speaker has been assigned to substantive role "${dto.deliveredByRoleId}" yet — assign the substantive speech first.`,
      );
    }
    round.replyAssignments[dto.replyRoleId] = dto.deliveredByRoleId;
    round.speakers[dto.replyRoleId] = round.speakers[dto.deliveredByRoleId];
    round.updatedAt = nowIso();
    return round;
  }

  logPoi(id: string, dto: LogPoiDto): Round {
    const round = this.get(id);
    this.assertEditable(round);
    round.poiLog.push({ ...dto });
    round.updatedAt = nowIso();
    return round;
  }

  /**
   * §3.5 — a format switch fully resets round state (status, timestamps,
   * reason-for-decision, lock state) by instantiating a brand-new Round
   * entity, rather than mutating the current one in place.
   */
  switchFormat(id: string, dto: SwitchFormatDto): Round {
    const previous = this.get(id);
    this.formats.get(dto.formatId); // validates format exists

    const fresh: Round = {
      id: randomUUID(),
      formatId: dto.formatId,
      motion: previous.motion,
      roundName: previous.roundName,
      judgeName: previous.judgeName,
      status: 'draft',
      createdAt: nowIso(),
      updatedAt: nowIso(),
      submittedAt: undefined,
      speakers: {},
      replyAssignments: {},
      scores: {},
      winnerSide: undefined,
      ranking: undefined,
      reasonForDecision: '',
      lowPointWinConfirmed: false,
      poiLog: [],
      aiAcceptedFields: [],
    };
    this.rounds.set(fresh.id, fresh);
    return fresh;
  }

  reopen(id: string): Round {
    const round = this.get(id);
    if (round.status !== 'submitted') {
      throw new BadRequestException('Only a submitted round can be reopened.');
    }
    round.status = 'reopened';
    round.updatedAt = nowIso();
    return round;
  }

  private assertEditable(round: Round) {
    if (round.status === 'submitted') {
      throw new BadRequestException('Round is locked. Reopen it before editing.');
    }
  }
}
