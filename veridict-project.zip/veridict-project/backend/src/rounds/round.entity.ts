export type RoundStatus = 'draft' | 'submitted' | 'reopened';

export interface SpeechScore {
  roleId: string;
  content?: number;
  style?: number;
  strategy?: number;
}

export interface PoiEvent {
  atSeconds: number;
  roleId: string; // speaker being interrupted
  fromRoleId?: string;
  accepted: boolean;
}

export interface Round {
  id: string;
  formatId: string;
  motion: string;
  roundName: string;
  judgeName: string;
  status: RoundStatus;
  createdAt: string;
  updatedAt: string;
  submittedAt?: string;
  speakers: Record<string, string>; // roleId -> speaker display name
  replyAssignments: Record<string, string>; // replyRoleId -> substantive roleId of the speaker delivering it
  scores: Record<string, SpeechScore>; // roleId -> score
  winnerSide?: string; // single-winner formats
  ranking?: string[]; // full-ranking formats, side keys ordered 1st..last
  reasonForDecision: string;
  lowPointWinConfirmed: boolean;
  poiLog: PoiEvent[];
  aiAcceptedFields: string[]; // which AI-suggested fields the judge explicitly accepted
}

export function nowIso(): string {
  return new Date().toISOString();
}
