import { Module } from '@nestjs/common';
import { RoundService } from './round.service';
import { RoundController } from './round.controller';
import { FormatModule } from '../formats/format.module';

@Module({
  imports: [FormatModule],
  controllers: [RoundController],
  providers: [RoundService],
  exports: [RoundService],
})
export class RoundsModule {}
