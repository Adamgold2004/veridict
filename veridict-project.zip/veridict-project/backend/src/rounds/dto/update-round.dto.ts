import { IsIn, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateRoundDto {
  @IsOptional()
  @IsString()
  motion?: string;

  @IsOptional()
  @IsString()
  roundName?: string;

  @IsOptional()
  @IsString()
  judgeName?: string;

  @IsOptional()
  @IsIn(['draft', 'submitted', 'reopened'])
  status?: 'draft' | 'submitted' | 'reopened';
}

export class AssignSpeakerDto {
  @IsString()
  @IsNotEmpty()
  roleId: string;

  @IsString()
  @IsNotEmpty()
  speakerName: string;
}

export class SwitchFormatDto {
  @IsIn(['wsdc', 'bp', 'policy'])
  formatId: 'wsdc' | 'bp' | 'policy';
}
