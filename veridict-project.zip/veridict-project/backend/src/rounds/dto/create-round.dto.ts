import { IsIn, IsNotEmpty, IsString } from 'class-validator';

export class CreateRoundDto {
  @IsIn(['wsdc', 'bp', 'policy'])
  formatId: 'wsdc' | 'bp' | 'policy';

  @IsString()
  @IsNotEmpty()
  motion: string;

  @IsString()
  @IsNotEmpty()
  roundName: string;

  @IsString()
  @IsNotEmpty()
  judgeName: string;
}
