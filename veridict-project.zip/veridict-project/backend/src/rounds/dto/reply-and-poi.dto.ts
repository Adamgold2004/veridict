import { IsBoolean, IsIn, IsInt, IsNotEmpty, IsOptional, IsString, Min } from 'class-validator';

export class AssignReplyDto {
  /** The reply role being filled, e.g. "PR" or "OR". */
  @IsString()
  @IsNotEmpty()
  replyRoleId: string;

  /**
   * The roleId of the substantive speech the reply speaker already
   * delivered in this round (§3.1 — only such a speaker is eligible).
   */
  @IsString()
  @IsNotEmpty()
  deliveredByRoleId: string;
}

export class LogPoiDto {
  @IsInt()
  @Min(0)
  atSeconds: number;

  @IsString()
  @IsNotEmpty()
  roleId: string;

  @IsOptional()
  @IsString()
  fromRoleId?: string;

  @IsBoolean()
  accepted: boolean;
}
