import { Module } from '@nestjs/common';
import { AiSuggestionService } from './ai-suggestion.service';
import { AiSuggestionController } from './ai-suggestion.controller';
import { FormatModule } from '../formats/format.module';
import { RoundsModule } from '../rounds/round.module';

@Module({
  imports: [FormatModule, RoundsModule],
  controllers: [AiSuggestionController],
  providers: [AiSuggestionService],
})
export class AiSuggestionModule {}
