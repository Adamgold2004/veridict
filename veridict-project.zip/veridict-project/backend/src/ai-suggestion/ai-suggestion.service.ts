import { BadRequestException, Injectable } from '@nestjs/common';
import { FormatService } from '../formats/format.service';
import { RoundService } from '../rounds/round.service';
import { nowIso } from '../rounds/round.entity';

export interface SpeakerFeedback {
  roleId: string;
  speakerName: string;
  strengths: string[];
  weaknesses: string[];
}

export interface AiSuggestionBundle {
  generatedAt: string;
  speakerFeedback: SpeakerFeedback[];
  draftReasonForDecision: string;
  fallacyFlags: { roleId: string; note: string }[];
  consistencyNudge?: string;
}

const ALLOWED_ACCEPT_FIELDS = new Set(['reasonForDecision']);

/**
 * This module is intentionally isolated: it only *reads* transcript/score
 * data already on the round, and never writes back to the ballot itself.
 * A judge must call `acceptField` explicitly, per field, for anything to
 * land on the round — mirroring the "non-binding, explicit acceptance"
 * trust boundary described in §6.
 *
 * The generation logic below is a deterministic local mock standing in for
 * a real model call, so the module runs without external dependencies.
 */
@Injectable()
export class AiSuggestionService {
  constructor(private readonly formats: FormatService, private readonly rounds: RoundService) {}

  generate(roundId: string): AiSuggestionBundle {
    const round = this.rounds.get(roundId);
    const format = this.formats.get(round.formatId);

    const speakerFeedback: SpeakerFeedback[] = format.roles
      .filter((role) => round.speakers[role.id])
      .map((role) => {
        const score = round.scores[role.id];
        const strengths: string[] = [];
        const weaknesses: string[] = [];
        if (score?.content !== undefined) {
          strengths.push(score.content >= (format.substantiveBands.content.max + format.substantiveBands.content.min) / 2
            ? 'Clear, well-substantiated argumentation.'
            : 'Argument structure was present but under-developed.');
        }
        if (score?.style !== undefined) {
          weaknesses.push(score.style < (format.substantiveBands.style?.max ?? 0)
            ? 'Delivery could be more varied in pace and emphasis.'
            : 'Strong, confident delivery throughout.');
        }
        if (strengths.length === 0) strengths.push('No transcript signal yet — score this speech to generate feedback.');
        if (weaknesses.length === 0) weaknesses.push('Nothing flagged.');
        return { roleId: role.id, speakerName: round.speakers[role.id], strengths, weaknesses };
      });

    const winnerLabel =
      format.rankingType === 'single-winner'
        ? round.winnerSide ?? '(no winner declared yet)'
        : (round.ranking ?? []).join(' > ') || '(no ranking declared yet)';

    const draftReasonForDecision = `This round was decided in favour of ${winnerLabel}. [Draft only — edit to reflect the actual clash in the room: which arguments were extended, dropped, or won on weighing, and why that side's case was preferred overall.]`;

    const fallacyFlags = format.roles
      .filter((role) => round.speakers[role.id])
      .slice(0, 2)
      .map((role) => ({ roleId: role.id, note: 'Consider whether a causal claim in this speech was fully warranted or merely asserted.' }));

    return {
      generatedAt: nowIso(),
      speakerFeedback,
      draftReasonForDecision,
      fallacyFlags,
      consistencyNudge: undefined, // would compare against the judge's historical average across a tournament
    };
  }

  acceptField(roundId: string, field: string, value: string) {
    if (!ALLOWED_ACCEPT_FIELDS.has(field)) {
      throw new BadRequestException(`Field "${field}" cannot be accepted from an AI suggestion.`);
    }
    const round = this.rounds.get(roundId);
    if (round.status === 'submitted') {
      throw new BadRequestException('Round is locked. Reopen it before editing.');
    }
    (round as any)[field] = value;
    if (!round.aiAcceptedFields.includes(field)) round.aiAcceptedFields.push(field);
    round.updatedAt = nowIso();
    return round;
  }
}
