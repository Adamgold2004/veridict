import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { IsIn, IsString } from 'class-validator';
import { AiSuggestionService } from './ai-suggestion.service';

class AcceptFieldDto {
  @IsIn(['reasonForDecision'])
  field: string;

  @IsString()
  value: string;
}

@Controller('api/rounds/:roundId/ai-suggestions')
export class AiSuggestionController {
  constructor(private readonly ai: AiSuggestionService) {}

  @Get()
  generate(@Param('roundId') roundId: string) {
    return this.ai.generate(roundId);
  }

  @Post('accept')
  accept(@Param('roundId') roundId: string, @Body() dto: AcceptFieldDto) {
    return this.ai.acceptField(roundId, dto.field, dto.value);
  }
}
