import { Injectable, NotFoundException } from '@nestjs/common';
import { FormatDefinition } from './format.types';
import { wsdcFormat } from './wsdc.format';
import { bpFormat } from './bp.format';
import { policyFormat } from './policy.format';

@Injectable()
export class FormatService {
  private readonly registry = new Map<string, FormatDefinition>([
    [wsdcFormat.id, wsdcFormat],
    [bpFormat.id, bpFormat],
    [policyFormat.id, policyFormat],
  ]);

  list(): FormatDefinition[] {
    return Array.from(this.registry.values());
  }

  get(id: string): FormatDefinition {
    const format = this.registry.get(id);
    if (!format) {
      throw new NotFoundException(`Unknown format "${id}". Registered formats: ${Array.from(this.registry.keys()).join(', ')}`);
    }
    return format;
  }
}
