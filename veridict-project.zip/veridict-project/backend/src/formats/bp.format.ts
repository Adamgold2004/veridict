import { FormatDefinition, FormatRole } from './format.types';

// §3.6 fix: every one of the 8 BP roles gets a unique bench-distinguishing
// badge — OG1, OG2, OO1, OO2, CG1, CG2, CO1, CO2 — never a reused label
// like "O1" or "C1" across benches.
const roles: FormatRole[] = [
  { id: 'OG1', label: 'Opening Government — Prime Minister', benchLabel: 'OG1', side: 'OG', order: 1, isReply: false },
  { id: 'OO1', label: 'Opening Opposition — Leader of Opposition', benchLabel: 'OO1', side: 'OO', order: 2, isReply: false },
  { id: 'OG2', label: 'Opening Government — Deputy PM', benchLabel: 'OG2', side: 'OG', order: 3, isReply: false },
  { id: 'OO2', label: 'Opening Opposition — Deputy Leader', benchLabel: 'OO2', side: 'OO', order: 4, isReply: false },
  { id: 'CG1', label: 'Closing Government — Member', benchLabel: 'CG1', side: 'CG', order: 5, isReply: false },
  { id: 'CO1', label: 'Closing Opposition — Member', benchLabel: 'CO1', side: 'CO', order: 6, isReply: false },
  { id: 'CG2', label: 'Closing Government — Whip', benchLabel: 'CG2', side: 'CG', order: 7, isReply: false },
  { id: 'CO2', label: 'Closing Opposition — Whip', benchLabel: 'CO2', side: 'CO', order: 8, isReply: false },
];

export const bpFormat: FormatDefinition = {
  id: 'bp',
  name: 'British Parliamentary',
  description: 'Four independent benches (OG, OO, CG, CO), each ranked 1st–4th with no ties and no omissions.',
  teamCount: 4,
  speechCount: 8,
  roles,
  rankingType: 'full-ranking',
  sides: [
    { key: 'OG', label: 'Opening Government' },
    { key: 'OO', label: 'Opening Opposition' },
    { key: 'CG', label: 'Closing Government' },
    { key: 'CO', label: 'Closing Opposition' },
  ],
  substantiveBands: {
    // BP scores a single holistic speaker score, not content/style/strategy.
    content: { min: 50, max: 100 },
  },
  hasReplySpeeches: false,
  replySideFor() {
    return undefined;
  },
};
