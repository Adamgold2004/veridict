import { FormatDefinition, FormatRole } from './format.types';

const roles: FormatRole[] = [
  { id: 'AFF1', label: 'Affirmative 1st Speaker', benchLabel: 'A1', side: 'AFF', order: 1, isReply: false },
  { id: 'NEG1', label: 'Negative 1st Speaker', benchLabel: 'N1', side: 'NEG', order: 2, isReply: false },
  { id: 'AFF2', label: 'Affirmative 2nd Speaker', benchLabel: 'A2', side: 'AFF', order: 3, isReply: false },
  { id: 'NEG2', label: 'Negative 2nd Speaker', benchLabel: 'N2', side: 'NEG', order: 4, isReply: false },
];

export const policyFormat: FormatDefinition = {
  id: 'policy',
  name: 'Policy Debate',
  description: 'Two-team policy format — 2 constructive speeches per side, single-winner decision, no reply speeches.',
  teamCount: 2,
  speechCount: 4,
  roles,
  rankingType: 'single-winner',
  sides: [
    { key: 'AFF', label: 'Affirmative' },
    { key: 'NEG', label: 'Negative' },
  ],
  substantiveBands: {
    content: { min: 25, max: 30 },
    style: { min: 25, max: 30 },
    strategy: { min: 25, max: 30 },
  },
  hasReplySpeeches: false,
  replySideFor() {
    return undefined;
  },
};
