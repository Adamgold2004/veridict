import { Controller, Get, Param } from '@nestjs/common';
import { FormatService } from './format.service';
import { scoringGuides } from './scoring-guide';

@Controller('api/formats')
export class FormatController {
  constructor(private readonly formats: FormatService) {}

  @Get()
  list() {
    return this.formats.list();
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.formats.get(id);
  }

  @Get(':id/scoring-guide')
  scoringGuide(@Param('id') id: string) {
    this.formats.get(id); // 404s on unknown format
    return scoringGuides[id] ?? { formatId: id, content: [], strategy: [] };
  }
}
