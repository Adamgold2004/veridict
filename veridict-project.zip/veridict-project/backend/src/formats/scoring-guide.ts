export interface BandDescriptor {
  band: string; // e.g. "24-27", "28-29", "30-32"
  descriptor: string;
}

export interface ScoringGuide {
  formatId: string;
  content: BandDescriptor[];
  style?: BandDescriptor[];
  strategy: BandDescriptor[];
}

// Descriptive language reflects the general shape of published WSDC/BP
// judging guidance (band ranges are illustrative, matching the bands
// wired into wsdc.format.ts / bp.format.ts / policy.format.ts).
export const scoringGuides: Record<string, ScoringGuide> = {
  wsdc: {
    formatId: 'wsdc',
    content: [
      { band: '24-26', descriptor: 'Arguments are asserted rather than proven; little or no evidence/mechanism given.' },
      { band: '27-29', descriptor: 'Arguments are structured and supported, but analysis stops short of full impact/weighing.' },
      { band: '30-32', descriptor: 'Arguments are deeply analyzed, well-evidenced, and explicitly weighed against the opposing case.' },
    ],
    style: [
      { band: '24-26', descriptor: 'Delivery is hesitant or monotone; limited engagement with the room.' },
      { band: '27-29', descriptor: 'Clear, controlled delivery with reasonable variation in pace and emphasis.' },
      { band: '30-32', descriptor: 'Persuasive, dynamic delivery that reinforces the substance of the speech.' },
    ],
    strategy: [
      { band: '24-26', descriptor: 'Speech largely ignores what has happened elsewhere in the debate.' },
      { band: '27-29', descriptor: 'Speech responds to the opposing case and allocates time reasonably.' },
      { band: '30-32', descriptor: 'Speech is tightly targeted at the live clash, with excellent time allocation and prioritization.' },
    ],
  },
  bp: {
    formatId: 'bp',
    content: [
      { band: '50-64', descriptor: 'Below the bar for competitive BP — largely assertive, little independent contribution.' },
      { band: '65-74', descriptor: 'A solid, competent speech that engages the motion and the room.' },
      { band: '75-84', descriptor: 'A strong speech with clear analysis and a distinct contribution from its bench.' },
      { band: '85-100', descriptor: 'An outstanding speech — highly persuasive, strategically sharp, and decisive for its bench.' },
    ],
    strategy: [],
  },
  policy: {
    formatId: 'policy',
    content: [
      { band: '25-26', descriptor: 'Case is under-developed; key stock issues are missing or unaddressed.' },
      { band: '27-28', descriptor: 'Case is coherent and responsive, with reasonable evidence.' },
      { band: '29-30', descriptor: 'Case is thoroughly developed, well-evidenced, and directly engages opposing arguments.' },
    ],
    style: [
      { band: '25-26', descriptor: 'Delivery is difficult to follow or lacks organization signposting.' },
      { band: '27-28', descriptor: 'Clear and organized delivery, reasonably easy to flow.' },
      { band: '29-30', descriptor: 'Highly organized, persuasive delivery that is easy to flow and engaging.' },
    ],
    strategy: [
      { band: '25-26', descriptor: 'Limited crystallization of the round; unclear voting issues.' },
      { band: '27-28', descriptor: 'Reasonable crystallization with identifiable voting issues.' },
      { band: '29-30', descriptor: 'Excellent crystallization — clear, prioritized voting issues tied to the flow.' },
    ],
  },
};
