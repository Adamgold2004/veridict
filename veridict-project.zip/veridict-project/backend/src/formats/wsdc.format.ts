import { FormatDefinition, FormatRole } from './format.types';

// Proposition: PM (1st), DPM (2nd), PW (3rd/Whip), PR (Reply)
// Opposition: LO (1st), DLO (2nd), OW (3rd/Whip), OR (Reply)
const roles: FormatRole[] = [
  { id: 'PM', label: 'Proposition 1st Speaker', benchLabel: 'P1', side: 'PROP', order: 1, isReply: false },
  { id: 'LO', label: 'Opposition 1st Speaker', benchLabel: 'O1', side: 'OPP', order: 2, isReply: false },
  { id: 'DPM', label: 'Proposition 2nd Speaker', benchLabel: 'P2', side: 'PROP', order: 3, isReply: false },
  { id: 'DLO', label: 'Opposition 2nd Speaker', benchLabel: 'O2', side: 'OPP', order: 4, isReply: false },
  { id: 'PW', label: 'Proposition 3rd Speaker (Whip)', benchLabel: 'P3', side: 'PROP', order: 5, isReply: false },
  { id: 'OW', label: 'Opposition 3rd Speaker (Whip)', benchLabel: 'O3', side: 'OPP', order: 6, isReply: false },
  // Reply order is reversed side (Opposition replies first), a WSDC convention.
  { id: 'OR', label: 'Opposition Reply', benchLabel: 'OR', side: 'OPP', order: 7, isReply: true },
  { id: 'PR', label: 'Proposition Reply', benchLabel: 'PR', side: 'PROP', order: 8, isReply: true },
];

export const wsdcFormat: FormatDefinition = {
  id: 'wsdc',
  name: 'WSDC (World Schools)',
  description: 'World Schools Debating Championships style — 3 substantive speeches per side plus 1 reply speech per side.',
  teamCount: 2,
  speechCount: 8,
  roles,
  rankingType: 'single-winner',
  sides: [
    { key: 'PROP', label: 'Proposition' },
    { key: 'OPP', label: 'Opposition' },
  ],
  substantiveBands: {
    content: { min: 24, max: 32 },
    style: { min: 24, max: 32 },
    strategy: { min: 24, max: 32 },
  },
  replyBands: {
    content: { min: 12, max: 16 },
    strategy: { min: 12, max: 16 },
    // no style band on a reply speech
  },
  hasReplySpeeches: true,
  replySideFor(roleId: string) {
    const role = roles.find((r) => r.id === roleId && r.isReply);
    return role?.side;
  },
};
