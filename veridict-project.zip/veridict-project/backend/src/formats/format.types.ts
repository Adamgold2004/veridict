export type RankingType = 'single-winner' | 'full-ranking';

export interface ScoreBand {
  min: number;
  max: number;
}

/**
 * Bands that apply to a speech. Substantive speeches typically score
 * content + style + strategy. Reply speeches (WSDC) score content +
 * strategy only — no style band exists for a reply.
 */
export interface SpeechScoreBands {
  content: ScoreBand;
  style?: ScoreBand; // absent for reply speeches, and for BP's holistic score
  strategy?: ScoreBand; // absent for BP's holistic score
}

export interface FormatRole {
  id: string; // stable machine id, e.g. "OG1"
  label: string; // human label shown in UI, e.g. "Opening Government 1"
  benchLabel: string; // short unique badge text, e.g. "OG1"
  side: string; // logical side/team grouping key, e.g. "OG", "PROP", "GOV"
  order: number; // speaking order within the round
  isReply: boolean;
}

export interface FormatDefinition {
  id: 'wsdc' | 'bp' | 'policy';
  name: string;
  description: string;
  teamCount: number;
  speechCount: number;
  roles: FormatRole[];
  rankingType: RankingType;
  sides: { key: string; label: string }[];
  substantiveBands: SpeechScoreBands;
  replyBands?: SpeechScoreBands; // only formats with reply speeches set this
  hasReplySpeeches: boolean;
  /**
   * Given a reply role id, returns the side it belongs to, used to
   * validate that only a speaker who delivered a substantive speech on
   * that side may be assigned the reply (§3.1).
   */
  replySideFor(roleId: string): string | undefined;
}
