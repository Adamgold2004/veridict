import { Module } from '@nestjs/common';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { FormatModule } from './formats/format.module';
import { RoundsModule } from './rounds/round.module';
import { ScoringModule } from './scoring/scoring.module';
import { BallotModule } from './ballot/ballot.module';
import { AiSuggestionModule } from './ai-suggestion/ai-suggestion.module';

@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', '..', 'frontend', 'dist'),
      exclude: ['/api/{*splat}'],
    }),
    FormatModule,
    RoundsModule,
    ScoringModule,
    BallotModule,
    AiSuggestionModule,
  ],
})
export class AppModule {}
