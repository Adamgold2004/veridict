import { Module } from '@nestjs/common';
import { ScoringService } from './scoring.service';
import { ScoringController } from './scoring.controller';
import { FormatModule } from '../formats/format.module';
import { RoundsModule } from '../rounds/round.module';

@Module({
  imports: [FormatModule, RoundsModule],
  controllers: [ScoringController],
  providers: [ScoringService],
  exports: [ScoringService],
})
export class ScoringModule {}
