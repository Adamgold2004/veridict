import { Body, Controller, Param, Post } from '@nestjs/common';
import { ScoringService } from './scoring.service';
import { SubmitScoreDto } from './dto/submit-score.dto';

@Controller('api/rounds/:roundId/scores')
export class ScoringController {
  constructor(private readonly scoring: ScoringService) {}

  @Post()
  submit(@Param('roundId') roundId: string, @Body() dto: SubmitScoreDto) {
    return this.scoring.submitScore(roundId, dto);
  }
}
