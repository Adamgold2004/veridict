import { BadRequestException, Injectable } from '@nestjs/common';
import { FormatService } from '../formats/format.service';
import { RoundService } from '../rounds/round.service';
import { ScoreBand, SpeechScoreBands } from '../formats/format.types';
import { SubmitScoreDto } from './dto/submit-score.dto';
import { Round, nowIso } from '../rounds/round.entity';

function checkBand(field: string, value: number | undefined, band: ScoreBand | undefined) {
  if (band === undefined) {
    if (value !== undefined) {
      throw new BadRequestException(`Field "${field}" is not scored in this format/speech-type and must be omitted.`);
    }
    return;
  }
  if (value === undefined) {
    throw new BadRequestException(`Field "${field}" is required (band ${band.min}–${band.max}).`);
  }
  if (!Number.isFinite(value) || value < band.min || value > band.max) {
    throw new BadRequestException(`Field "${field}" = ${value} is outside the valid band ${band.min}–${band.max}.`);
  }
}

@Injectable()
export class ScoringService {
  constructor(private readonly formats: FormatService, private readonly rounds: RoundService) {}

  /**
   * §2.1 / §3.3 — this is the *server-side* source of truth. The client
   * may clamp/reject in real time for UX, but every score is re-validated
   * here regardless of what the client already checked.
   */
  submitScore(roundId: string, dto: SubmitScoreDto): Round {
    const round = this.rounds.get(roundId);
    if (round.status === 'submitted') {
      throw new BadRequestException('Round is locked. Reopen it before editing scores.');
    }
    const format = this.formats.get(round.formatId);
    const role = format.roles.find((r) => r.id === dto.roleId);
    if (!role) {
      throw new BadRequestException(`Role "${dto.roleId}" does not exist in format "${format.id}"`);
    }

    const bands: SpeechScoreBands = role.isReply && format.replyBands ? format.replyBands : format.substantiveBands;

    checkBand('content', dto.content, bands.content);
    checkBand('style', dto.style, bands.style);
    checkBand('strategy', dto.strategy, bands.strategy);

    round.scores[dto.roleId] = {
      roleId: dto.roleId,
      content: dto.content,
      style: dto.style,
      strategy: dto.strategy,
    };
    round.updatedAt = nowIso();
    return round;
  }

  /** Total speaker points for a given side, across substantive + reply speeches already scored. */
  totalForSide(round: Round, sideKey: string): number {
    const format = this.formats.get(round.formatId);
    let total = 0;
    for (const role of format.roles) {
      if (role.side !== sideKey) continue;
      const score = round.scores[role.id];
      if (!score) continue;
      total += (score.content ?? 0) + (score.style ?? 0) + (score.strategy ?? 0);
    }
    return total;
  }
}
