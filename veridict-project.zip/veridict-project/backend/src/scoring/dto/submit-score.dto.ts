import { IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class SubmitScoreDto {
  @IsString()
  roleId: string;

  @IsNumber()
  @Min(0)
  content: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  style?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  strategy?: number;
}
