import { Module } from '@nestjs/common';
import { BallotService } from './ballot.service';
import { BallotController } from './ballot.controller';
import { FormatModule } from '../formats/format.module';
import { RoundsModule } from '../rounds/round.module';
import { ScoringModule } from '../scoring/scoring.module';

@Module({
  imports: [FormatModule, RoundsModule, ScoringModule],
  controllers: [BallotController],
  providers: [BallotService],
})
export class BallotModule {}
