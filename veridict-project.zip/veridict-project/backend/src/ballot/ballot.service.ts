import { BadRequestException, Injectable } from '@nestjs/common';
import { FormatService } from '../formats/format.service';
import { RoundService } from '../rounds/round.service';
import { ScoringService } from '../scoring/scoring.service';
import { SetResultDto, SetReasonDto } from './dto/set-result.dto';
import { Round, nowIso } from '../rounds/round.entity';

export interface SubmitCheckResult {
  ok: boolean;
  errors: string[];
  lowPointWin?: { winnerSide: string; winnerTotal: number; opponentSide: string; opponentTotal: number };
}

@Injectable()
export class BallotService {
  constructor(
    private readonly formats: FormatService,
    private readonly rounds: RoundService,
    private readonly scoring: ScoringService,
  ) {}

  setResult(roundId: string, dto: SetResultDto): Round {
    const round = this.rounds.get(roundId);
    this.assertEditable(round);
    const format = this.formats.get(round.formatId);

    if (format.rankingType === 'single-winner') {
      if (!dto.winnerSide || !format.sides.some((s) => s.key === dto.winnerSide)) {
        throw new BadRequestException(`winnerSide must be one of: ${format.sides.map((s) => s.key).join(', ')}`);
      }
      round.winnerSide = dto.winnerSide;
      round.ranking = undefined;
    } else {
      const sideKeys = format.sides.map((s) => s.key);
      const ranking = dto.ranking ?? [];
      const isCompletePermutation =
        ranking.length === sideKeys.length &&
        new Set(ranking).size === sideKeys.length &&
        ranking.every((k) => sideKeys.includes(k));
      if (!isCompletePermutation) {
        throw new BadRequestException(
          `ranking must contain every side exactly once (no ties, no omissions): ${sideKeys.join(', ')}`,
        );
      }
      round.ranking = ranking;
      round.winnerSide = undefined;
    }
    // Declaring/changing a result invalidates any prior low-point-win confirmation.
    round.lowPointWinConfirmed = false;
    round.updatedAt = nowIso();
    return round;
  }

  setReason(roundId: string, dto: SetReasonDto): Round {
    const round = this.rounds.get(roundId);
    this.assertEditable(round);
    round.reasonForDecision = dto.reasonForDecision;
    round.updatedAt = nowIso();
    return round;
  }

  confirmLowPointWin(roundId: string): Round {
    const round = this.rounds.get(roundId);
    this.assertEditable(round);
    round.lowPointWinConfirmed = true;
    round.updatedAt = nowIso();
    return round;
  }

  /**
   * §3.4 — compare the declared winner's summed speaker points against the
   * opponent's before allowing submission. Only meaningful for two-side,
   * single-winner formats.
   */
  private detectLowPointWin(round: Round): SubmitCheckResult['lowPointWin'] {
    const format = this.formats.get(round.formatId);
    if (format.rankingType !== 'single-winner' || !round.winnerSide) return undefined;
    const opponentSide = format.sides.find((s) => s.key !== round.winnerSide);
    if (!opponentSide) return undefined;

    const winnerTotal = this.scoring.totalForSide(round, round.winnerSide);
    const opponentTotal = this.scoring.totalForSide(round, opponentSide.key);

    if (winnerTotal < opponentTotal) {
      return { winnerSide: round.winnerSide, winnerTotal, opponentSide: opponentSide.key, opponentTotal };
    }
    return undefined;
  }

  /** Runs every §4.4-style invariant without mutating state — used by both the UI preview and the real submit call. */
  check(roundId: string): SubmitCheckResult {
    const round = this.rounds.get(roundId);
    const format = this.formats.get(round.formatId);
    const errors: string[] = [];

    // Every role must have an assigned speaker.
    for (const role of format.roles) {
      if (!round.speakers[role.id]) errors.push(`No speaker assigned for role "${role.id}".`);
    }

    // §3.1 — every reply role must trace back to a substantive speaker on the same side.
    for (const role of format.roles.filter((r) => r.isReply)) {
      if (round.speakers[role.id] && !round.replyAssignments[role.id]) {
        errors.push(`Reply role "${role.id}" is missing a valid delivered-by assignment.`);
      }
    }

    // Every role must have a band-valid score on file.
    for (const role of format.roles) {
      if (!round.scores[role.id]) errors.push(`No score recorded for role "${role.id}".`);
    }

    // Result must be declared, format-appropriate.
    if (format.rankingType === 'single-winner') {
      if (!round.winnerSide) errors.push('No winner has been declared.');
    } else {
      const sideKeys = format.sides.map((s) => s.key);
      const ranking = round.ranking ?? [];
      const isCompletePermutation =
        ranking.length === sideKeys.length && new Set(ranking).size === sideKeys.length && ranking.every((k) => sideKeys.includes(k));
      if (!isCompletePermutation) errors.push('Full ranking (1st–4th, all teams, no ties/omissions) has not been completed.');
    }

    if (!round.reasonForDecision || round.reasonForDecision.trim().length === 0) {
      errors.push('Reason for decision is required.');
    }

    const lowPointWin = errors.length === 0 ? this.detectLowPointWin(round) : undefined;
    if (lowPointWin && !round.lowPointWinConfirmed) {
      errors.push('This is a low-point win — please confirm this is intentional before submitting.');
    }

    return { ok: errors.length === 0, errors, lowPointWin };
  }

  submit(roundId: string): Round {
    const round = this.rounds.get(roundId);
    this.assertEditable(round);
    const result = this.check(roundId);
    if (!result.ok) {
      throw new BadRequestException({ message: 'Ballot cannot be submitted.', errors: result.errors, lowPointWin: result.lowPointWin });
    }
    round.status = 'submitted';
    round.submittedAt = nowIso();
    round.updatedAt = nowIso();
    return round;
  }

  private assertEditable(round: Round) {
    if (round.status === 'submitted') {
      throw new BadRequestException('Round is locked. Reopen it before editing.');
    }
  }
}
