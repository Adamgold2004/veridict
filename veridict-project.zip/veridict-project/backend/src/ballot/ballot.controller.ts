import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { BallotService } from './ballot.service';
import { SetResultDto, SetReasonDto } from './dto/set-result.dto';

@Controller('api/rounds/:roundId/ballot')
export class BallotController {
  constructor(private readonly ballot: BallotService) {}

  @Post('result')
  setResult(@Param('roundId') roundId: string, @Body() dto: SetResultDto) {
    return this.ballot.setResult(roundId, dto);
  }

  @Post('reason')
  setReason(@Param('roundId') roundId: string, @Body() dto: SetReasonDto) {
    return this.ballot.setReason(roundId, dto);
  }

  @Post('confirm-low-point-win')
  confirmLowPointWin(@Param('roundId') roundId: string) {
    return this.ballot.confirmLowPointWin(roundId);
  }

  @Get('check')
  check(@Param('roundId') roundId: string) {
    return this.ballot.check(roundId);
  }

  @Post('submit')
  submit(@Param('roundId') roundId: string) {
    return this.ballot.submit(roundId);
  }
}
