import { ArrayNotEmpty, IsArray, IsOptional, IsString } from 'class-validator';

export class SetResultDto {
  /** Single-winner formats (WSDC, Policy): the winning side key, e.g. "PROP". */
  @IsOptional()
  @IsString()
  winnerSide?: string;

  /** Full-ranking formats (BP): all side keys, ordered 1st → last, no ties/omissions. */
  @IsOptional()
  @IsArray()
  @ArrayNotEmpty()
  ranking?: string[];
}

export class SetReasonDto {
  @IsString()
  reasonForDecision: string;
}
