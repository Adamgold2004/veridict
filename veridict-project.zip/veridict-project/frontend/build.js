const fs = require('fs');
const path = require('path');

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

const root = __dirname;
copyDir(path.join(root, 'src', 'js'), path.join(root, 'dist', 'js'));
fs.copyFileSync(path.join(root, 'index.html'), path.join(root, 'dist', 'index.html'));

if (fs.existsSync(path.join(root, 'public'))) {
  copyDir(path.join(root, 'public'), path.join(root, 'dist'));
}

console.log('Frontend build complete -> dist/');
