import { api } from '../lib/api.js';

/**
 * Renders one score card for a role: content / style / strategy inputs
 * (whichever bands the format declares for that speech type), with
 * real-time client-side band feedback and a debounced server submit
 * that is the actual source of truth (§3.3 — server always re-validates).
 */
export function renderScoreCard(container, { round, format, role, speakerName, existingScore, onSaved }) {
  const bands = role.isReply && format.replyBands ? format.replyBands : format.substantiveBands;
  const fields = ['content', 'style', 'strategy'].filter((f) => bands[f]);

  const card = document.createElement('div');
  card.className = 'score-card';

  const header = document.createElement('div');
  header.className = 'score-card-header';
  header.innerHTML = `
    <span class="badge badge-side" data-side="${role.side}">${role.benchLabel}</span>
    <div>
      <div class="speaker-name">${escapeHtml(speakerName)}</div>
      <div class="role-label">${escapeHtml(role.label)}${role.isReply ? ' · Reply (content + strategy only)' : ''}</div>
    </div>
  `;
  card.appendChild(header);

  const fieldsWrap = document.createElement('div');
  fieldsWrap.className = 'score-fields';

  const inputs = {};

  for (const field of fields) {
    const band = bands[field];
    const wrap = document.createElement('div');
    wrap.className = 'score-field';
    wrap.dataset.state = 'empty';

    const label = document.createElement('label');
    label.innerHTML = `<span>${field}</span><span class="band-hint">${band.min}–${band.max}</span>`;
    wrap.appendChild(label);

    const input = document.createElement('input');
    input.type = 'number';
    input.min = String(band.min);
    input.max = String(band.max);
    input.step = '1';
    if (existingScore?.[field] !== undefined) {
      input.value = existingScore[field];
      wrap.dataset.state = 'valid';
    }
    wrap.appendChild(input);
    fieldsWrap.appendChild(wrap);
    inputs[field] = input;

    input.addEventListener('input', () => {
      const val = Number(input.value);
      if (input.value === '') {
        wrap.dataset.state = 'empty';
        return;
      }
      const inBand = Number.isFinite(val) && val >= band.min && val <= band.max;
      wrap.dataset.state = inBand ? 'valid' : 'invalid';
      if (!inBand) shake(wrap);
    });

    input.addEventListener('blur', () => trySubmit());
  }

  card.appendChild(fieldsWrap);
  container.appendChild(card);

  let saving = false;
  async function trySubmit() {
    if (saving) return;
    const payload = { roleId: role.id };
    let hasAll = true;
    for (const field of fields) {
      const raw = inputs[field].value;
      if (raw === '') { hasAll = false; continue; }
      payload[field] = Number(raw);
    }
    if (!hasAll) return;

    saving = true;
    try {
      const updatedRound = await api.submitScore(round.id, payload);
      for (const field of fields) {
        const wrap = inputs[field].closest('.score-field');
        wrap.dataset.state = 'valid';
      }
      onSaved?.(updatedRound);
    } catch (err) {
      // Server is the real source of truth (§3.3) — a client-side "valid"
      // field can still be rejected server-side, so surface it the same way.
      for (const field of fields) {
        const wrap = inputs[field].closest('.score-field');
        wrap.dataset.state = 'invalid';
        shake(wrap);
      }
      window.veridictToast?.(err.message || 'Score rejected by server.', 'error');
    } finally {
      saving = false;
    }
  }
}

function shake(el) {
  el.classList.add('is-shaking');
  if (window.gsap) {
    window.gsap.fromTo(
      el,
      { x: 0 },
      { x: 6, duration: 0.06, repeat: 5, yoyo: true, ease: 'power1.inOut', onComplete: () => el.classList.remove('is-shaking') },
    );
  } else {
    setTimeout(() => el.classList.remove('is-shaking'), 300);
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}
