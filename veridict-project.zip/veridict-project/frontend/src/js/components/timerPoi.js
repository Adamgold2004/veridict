import { api } from '../lib/api.js';
import { speechLengthFor, speechLengths } from '../lib/speechLengths.js';

const RING_RADIUS = 54;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

export function renderTimerPoi(container, { round, format }) {
  const cfg = speechLengths[format.id] ?? speechLengths.wsdc;
  const speakingRoles = format.roles.filter((r) => round.speakers[r.id]);

  const panel = document.createElement('div');
  panel.className = 'timer-panel';
  panel.innerHTML = `
    <div class="timer-ring-wrap">
      <svg viewBox="0 0 128 128" width="128" height="128">
        <circle class="ring-bg" cx="64" cy="64" r="${RING_RADIUS}"></circle>
        <circle class="ring-progress" cx="64" cy="64" r="${RING_RADIUS}"
          stroke-dasharray="${RING_CIRCUMFERENCE}" stroke-dashoffset="0"></circle>
      </svg>
      <div class="timer-readout mono">0:00</div>
    </div>
    <div class="timer-controls">
      <div class="field">
        <label>Current speaker</label>
        <select class="speaker-select"></select>
      </div>
      <div class="timer-buttons">
        <button class="btn btn-primary btn-sm" data-action="start">Start</button>
        <button class="btn btn-sm" data-action="pause">Pause</button>
        <button class="btn btn-ghost btn-sm" data-action="reset">Reset</button>
      </div>
      <p class="text-sm text-muted timer-meta"></p>
    </div>
    <div class="poi-panel">
      <div class="poi-toggle-row">
        <button class="btn btn-sm" data-action="poi-accept">POI accepted</button>
        <button class="btn btn-ghost btn-sm" data-action="poi-decline">POI declined</button>
        <span class="text-sm text-muted poi-hint"></span>
      </div>
      <div class="poi-log"></div>
    </div>
  `;
  container.appendChild(panel);

  const select = panel.querySelector('.speaker-select');
  for (const role of speakingRoles) {
    const opt = document.createElement('option');
    opt.value = role.id;
    opt.textContent = `${role.benchLabel} — ${round.speakers[role.id]}`;
    select.appendChild(opt);
  }

  const readout = panel.querySelector('.timer-readout');
  const ring = panel.querySelector('.ring-progress');
  const meta = panel.querySelector('.timer-meta');
  const poiAcceptBtn = panel.querySelector('[data-action="poi-accept"]');
  const poiDeclineBtn = panel.querySelector('[data-action="poi-decline"]');
  const poiHint = panel.querySelector('.poi-hint');
  const poiLogEl = panel.querySelector('.poi-log');

  let totalSeconds = speechLengthFor(format.id, currentRole()?.isReply) || 60;
  let elapsed = 0;
  let intervalId = null;
  let lastZoneWasProtected = false;

  function currentRole() {
    return speakingRoles.find((r) => r.id === select.value) || speakingRoles[0];
  }

  function inProtectedZone() {
    if (!cfg.protectedSeconds) return false;
    return elapsed < cfg.protectedSeconds || elapsed > totalSeconds - cfg.protectedSeconds;
  }

  function fmt(s) {
    const sign = s < 0 ? '-' : '';
    const a = Math.abs(Math.round(s));
    const m = Math.floor(a / 60);
    const sec = a % 60;
    return `${sign}${m}:${String(sec).padStart(2, '0')}`;
  }

  function render() {
    const remaining = totalSeconds - elapsed;
    readout.textContent = fmt(remaining);
    const progress = Math.min(elapsed / totalSeconds, 1.2);
    const offset = RING_CIRCUMFERENCE * (1 - Math.min(progress, 1));
    if (window.gsap) {
      window.gsap.to(ring, { strokeDashoffset: offset, duration: 0.3, ease: 'linear' });
    } else {
      ring.setAttribute('stroke-dashoffset', String(offset));
    }
    ring.classList.toggle('is-overtime', remaining < 0);
    ring.classList.toggle('is-protected', inProtectedZone() && remaining >= 0);

    const nowProtected = inProtectedZone();
    if (nowProtected !== lastZoneWasProtected) {
      lastZoneWasProtected = nowProtected;
      if (elapsed > 0) bellFlash();
    }

    const poiAllowed = cfg.poiAllowed && !nowProtected && remaining > 0;
    poiAcceptBtn.disabled = !poiAllowed;
    poiDeclineBtn.disabled = !poiAllowed;
    poiHint.textContent = !cfg.poiAllowed
      ? 'POIs are not part of this format.'
      : nowProtected
      ? 'Protected time — POIs disabled.'
      : '';

    meta.textContent = `${currentRole()?.label ?? ''} · ${totalSeconds / 60} min speech${
      cfg.protectedSeconds ? `, ${cfg.protectedSeconds / 60}-min protected time each end` : ''
    }`;
  }

  function bellFlash() {
    panel.classList.remove('is-bell-flash');
    // eslint-disable-next-line no-unused-expressions
    void panel.offsetWidth; // restart CSS animation
    panel.classList.add('is-bell-flash');
    if (window.gsap) {
      window.gsap.fromTo(panel, { boxShadow: '0 0 0 0 rgba(224,169,64,0.6)' }, { boxShadow: '0 0 0 0 rgba(224,169,64,0)', duration: 0.5 });
    }
  }

  function tick() {
    elapsed += 0.2;
    render();
  }

  panel.querySelector('[data-action="start"]').addEventListener('click', () => {
    if (intervalId) return;
    intervalId = setInterval(tick, 200);
  });
  panel.querySelector('[data-action="pause"]').addEventListener('click', () => {
    clearInterval(intervalId);
    intervalId = null;
  });
  panel.querySelector('[data-action="reset"]').addEventListener('click', () => {
    clearInterval(intervalId);
    intervalId = null;
    elapsed = 0;
    lastZoneWasProtected = false;
    render();
  });

  select.addEventListener('change', () => {
    clearInterval(intervalId);
    intervalId = null;
    elapsed = 0;
    totalSeconds = speechLengthFor(format.id, currentRole()?.isReply) || 60;
    lastZoneWasProtected = false;
    render();
  });

  async function logPoi(accepted) {
    const role = currentRole();
    try {
      await api.logPoi(round.id, { atSeconds: Math.round(elapsed), roleId: role.id, accepted });
      addLogEntry(role, accepted, elapsed);
    } catch (err) {
      window.veridictToast?.(err.message || 'Could not log POI.', 'error');
    }
  }

  function addLogEntry(role, accepted, atSeconds) {
    const item = document.createElement('div');
    item.className = `poi-log-item ${accepted ? 'is-accepted' : 'is-declined'}`;
    item.innerHTML = `<span>${role.benchLabel} · ${fmt(atSeconds)}</span><span>${accepted ? 'Accepted' : 'Declined'}</span>`;
    poiLogEl.prepend(item);
  }

  poiAcceptBtn.addEventListener('click', () => logPoi(true));
  poiDeclineBtn.addEventListener('click', () => logPoi(false));

  for (const evt of round.poiLog ?? []) {
    const role = format.roles.find((r) => r.id === evt.roleId);
    if (role) addLogEntry(role, evt.accepted, evt.atSeconds);
  }

  render();
}
