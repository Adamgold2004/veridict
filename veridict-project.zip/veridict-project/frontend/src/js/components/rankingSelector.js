/**
 * Renders a forced full-ranking control: N slots (1st..Nth), each a
 * <select> of side keys. No ties, no omissions — every side must be
 * used exactly once before onChange reports a complete ranking.
 *
 * @param {HTMLElement} container
 * @param {{key:string,label:string}[]} sides
 * @param {string[]|undefined} initialRanking
 * @param {(ranking: (string|null)[], isComplete: boolean) => void} onChange
 */
export function renderRankingSelector(container, sides, initialRanking, onChange) {
  container.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'ranking-selector';

  const current = sides.map((_, i) => initialRanking?.[i] ?? null);

  function selectsUsed() {
    return current.filter(Boolean);
  }

  function renderSlots() {
    wrap.innerHTML = '';
    sides.forEach((_, i) => {
      const slot = document.createElement('div');
      slot.className = 'ranking-slot';

      const pos = document.createElement('span');
      pos.className = 'ranking-position mono';
      pos.textContent = ordinal(i + 1);
      slot.appendChild(pos);

      const select = document.createElement('select');
      const blank = document.createElement('option');
      blank.value = '';
      blank.textContent = '— select side —';
      select.appendChild(blank);

      for (const side of sides) {
        const used = selectsUsed();
        const isUsedElsewhere = used.includes(side.key) && current[i] !== side.key;
        const opt = document.createElement('option');
        opt.value = side.key;
        opt.textContent = side.label;
        opt.disabled = isUsedElsewhere;
        if (current[i] === side.key) opt.selected = true;
        select.appendChild(opt);
      }

      select.addEventListener('change', () => {
        current[i] = select.value || null;
        renderSlots();
        const isComplete = current.every(Boolean) && new Set(current).size === sides.length;
        onChange(current.slice(), isComplete);
      });

      slot.appendChild(select);
      wrap.appendChild(slot);
    });

    const status = document.createElement('div');
    const isComplete = current.every(Boolean) && new Set(current).size === sides.length;
    status.className = `ranking-status ${isComplete ? 'is-complete' : 'is-incomplete'}`;
    status.textContent = isComplete
      ? `Full ranking complete: ${current.join(' > ')}`
      : `Assign every side to a unique position (${selectsUsed().length}/${sides.length} placed).`;
    wrap.appendChild(status);
  }

  renderSlots();
  container.appendChild(wrap);
}

function ordinal(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}
