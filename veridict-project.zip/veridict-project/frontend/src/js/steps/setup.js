import { api } from '../lib/api.js';
import { setState, state } from '../lib/state.js';

export async function renderSetup(container, { goNext }) {
  container.innerHTML = '<h2 class="section-heading">Setup</h2><p class="text-muted">Loading formats…</p>';
  const formats = await api.listFormats();

  container.innerHTML = `
    <div class="step-setup">
      <h2 class="section-heading">Setup</h2>
      <div class="format-options" role="radiogroup" aria-label="Debate format"></div>
      <div class="field-grid">
        <div class="field">
          <label for="f-round-name">Round name</label>
          <input id="f-round-name" type="text" placeholder="e.g. Octofinal 3" />
        </div>
        <div class="field">
          <label for="f-judge-name">Judge name</label>
          <input id="f-judge-name" type="text" placeholder="Your name" />
        </div>
        <div class="field" style="grid-column: 1 / -1;">
          <label for="f-motion">Motion</label>
          <textarea id="f-motion" placeholder="This House would…"></textarea>
        </div>
      </div>
    </div>
  `;

  const optionsEl = container.querySelector('.format-options');
  let selectedFormatId = state.round?.formatId ?? null;

  function renderOptions() {
    optionsEl.innerHTML = '';
    for (const format of formats) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `format-option${selectedFormatId === format.id ? ' is-selected' : ''}`;
      btn.setAttribute('role', 'radio');
      btn.setAttribute('aria-checked', String(selectedFormatId === format.id));
      btn.innerHTML = `<div class="format-name">${format.name}</div><div class="format-desc">${format.description}</div>`;
      btn.addEventListener('click', () => {
        selectedFormatId = format.id;
        renderOptions();
      });
      optionsEl.appendChild(btn);
    }
  }
  renderOptions();

  const roundNameInput = container.querySelector('#f-round-name');
  const judgeNameInput = container.querySelector('#f-judge-name');
  const motionInput = container.querySelector('#f-motion');

  if (state.round) {
    roundNameInput.value = state.round.roundName;
    judgeNameInput.value = state.round.judgeName;
    motionInput.value = state.round.motion;
  }

  goNext.disabled = false;
  goNext.onclick = async () => {
    if (!selectedFormatId) {
      window.veridictToast?.('Choose a format to continue.', 'error');
      return;
    }
    if (!roundNameInput.value || !judgeNameInput.value || !motionInput.value) {
      window.veridictToast?.('Fill in round name, judge name, and motion.', 'error');
      return;
    }

    const dto = {
      formatId: selectedFormatId,
      roundName: roundNameInput.value,
      judgeName: judgeNameInput.value,
      motion: motionInput.value,
    };

    let round;
    if (!state.round) {
      round = await api.createRound(dto);
    } else if (state.round.formatId !== selectedFormatId) {
      // §3.5 — a format switch fully resets round state via a brand-new Round entity.
      round = await api.switchFormat(state.round.id, { formatId: selectedFormatId });
      round = await api.updateRound(round.id, {
        roundName: dto.roundName,
        judgeName: dto.judgeName,
        motion: dto.motion,
      });
    } else {
      round = await api.updateRound(state.round.id, {
        roundName: dto.roundName,
        judgeName: dto.judgeName,
        motion: dto.motion,
      });
    }

    const format = await api.getFormat(round.formatId);
    setState({ roundId: round.id, round, format });
    document.dispatchEvent(new CustomEvent('veridict:advance'));
  };
}
