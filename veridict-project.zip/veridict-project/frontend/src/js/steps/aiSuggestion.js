import { api } from '../lib/api.js';
import { setState, state } from '../lib/state.js';

export async function renderAiSuggestion(container, { goNext }) {
  if (!state.round) {
    container.innerHTML = '<p class="text-muted">Complete Setup first.</p>';
    goNext.disabled = true;
    return;
  }

  container.innerHTML = `
    <div class="step-ai">
      <h2 class="section-heading">AI Suggestion</h2>
      <div class="ai-disclaimer">
        Private and advisory only. Nothing here is written to the ballot unless you explicitly accept it, field by field.
      </div>
      <p class="text-muted">Generating suggestions…</p>
    </div>
  `;

  const bundle = await api.getAiSuggestions(state.roundId);
  const body = container.querySelector('.step-ai');
  body.querySelectorAll('p').forEach((p) => p.remove());

  const feedbackWrap = document.createElement('div');
  feedbackWrap.innerHTML = '<h3>Per-speaker feedback</h3>';
  for (const sf of bundle.speakerFeedback) {
    const card = document.createElement('div');
    card.className = 'ai-suggestion-card';
    card.innerHTML = `
      <div class="ai-suggestion-label">${sf.roleId} — ${escapeHtml(sf.speakerName)}</div>
      <div class="ai-suggestion-text"><strong>Strengths:</strong> ${sf.strengths.map(escapeHtml).join(' ')}<br/>
      <strong>Watch for:</strong> ${sf.weaknesses.map(escapeHtml).join(' ')}</div>
    `;
    feedbackWrap.appendChild(card);
  }
  body.appendChild(feedbackWrap);

  if (bundle.fallacyFlags?.length) {
    const flagsWrap = document.createElement('div');
    flagsWrap.innerHTML = '<h3 style="margin-top:20px;">Flagged for attention</h3>';
    for (const flag of bundle.fallacyFlags) {
      const card = document.createElement('div');
      card.className = 'ai-suggestion-card';
      card.innerHTML = `<div class="ai-suggestion-label">${flag.roleId}</div><div class="ai-suggestion-text">${escapeHtml(flag.note)}</div>`;
      flagsWrap.appendChild(card);
    }
    body.appendChild(flagsWrap);
  }

  const reasonWrap = document.createElement('div');
  reasonWrap.style.marginTop = '20px';
  reasonWrap.innerHTML = `
    <h3>Draft reason for decision</h3>
    <div class="ai-suggestion-card">
      <div class="ai-suggestion-text">${escapeHtml(bundle.draftReasonForDecision)}</div>
      <button class="btn btn-sm" data-action="accept-reason">Accept into ballot</button>
      <span class="accepted-tag" style="display:none;margin-left:8px;">✓ Accepted</span>
    </div>
  `;
  body.appendChild(reasonWrap);

  const acceptBtn = reasonWrap.querySelector('[data-action="accept-reason"]');
  const acceptedTag = reasonWrap.querySelector('.accepted-tag');
  if (state.round.aiAcceptedFields?.includes('reasonForDecision')) {
    acceptedTag.style.display = 'inline';
    acceptBtn.textContent = 'Re-accept (overwrite ballot text)';
  }
  acceptBtn.addEventListener('click', async () => {
    const updated = await api.acceptAiField(state.roundId, 'reasonForDecision', bundle.draftReasonForDecision);
    setState({ round: updated });
    acceptedTag.style.display = 'inline';
    window.veridictToast?.('Draft accepted into the ballot\u2019s reason for decision. You can still edit it there.', 'success');
  });

  goNext.disabled = false;
  goNext.onclick = () => document.dispatchEvent(new CustomEvent('veridict:advance'));
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}
