import { api } from '../lib/api.js';
import { setState, state } from '../lib/state.js';
import { renderTimerPoi } from '../components/timerPoi.js';

export async function renderSpeeches(container, { goNext }) {
  if (!state.round) {
    container.innerHTML = '<p class="text-muted">Complete Setup first.</p>';
    goNext.disabled = true;
    return;
  }

  const round = await api.getRound(state.roundId);
  const format = state.format ?? (await api.getFormat(round.formatId));
  setState({ round, format });

  container.innerHTML = `
    <div class="step-speeches">
      <h2 class="section-heading">Speeches</h2>
      <div class="field" style="max-width:280px;margin-bottom:16px;">
        <label><input type="checkbox" id="f-transcript-toggle" /> Transcript / recording in progress</label>
      </div>
      <h3>Roles</h3>
      <div class="role-list"></div>
      <div class="reply-list"></div>
      <h3 style="margin-top:24px;">Timer &amp; POI</h3>
      <div class="timer-slot"></div>
    </div>
  `;

  const roleListEl = container.querySelector('.role-list');
  const replyListEl = container.querySelector('.reply-list');
  const timerSlot = container.querySelector('.timer-slot');

  for (const role of format.roles.filter((r) => !r.isReply)) {
    const row = document.createElement('div');
    row.className = 'speech-role-row';
    row.innerHTML = `
      <span class="badge badge-side" data-side="${role.side}">${role.benchLabel}</span>
      <span class="role-name">${role.label}</span>
      <input type="text" placeholder="Speaker name" value="${round.speakers[role.id] ?? ''}" />
    `;
    const input = row.querySelector('input');
    input.addEventListener('blur', async () => {
      if (!input.value.trim()) return;
      const updated = await api.assignSpeaker(round.id, { roleId: role.id, speakerName: input.value.trim() });
      setState({ round: updated });
      refreshTimer(updated);
    });
    roleListEl.appendChild(row);
  }

  if (format.hasReplySpeeches) {
    const heading = document.createElement('h3');
    heading.style.marginTop = '20px';
    heading.textContent = 'Reply speeches';
    replyListEl.appendChild(heading);

    for (const replyRole of format.roles.filter((r) => r.isReply)) {
      const eligible = format.roles.filter((r) => !r.isReply && r.side === replyRole.side);
      const row = document.createElement('div');
      row.className = 'reply-row';
      row.innerHTML = `
        <span class="badge badge-side" data-side="${replyRole.side}">${replyRole.benchLabel}</span>
        <span class="role-name text-sm">${replyRole.label} — delivered by:</span>
        <select></select>
      `;
      const select = row.querySelector('select');
      const blank = document.createElement('option');
      blank.value = '';
      blank.textContent = '— select speaker —';
      select.appendChild(blank);
      for (const role of eligible) {
        const opt = document.createElement('option');
        opt.value = role.id;
        opt.textContent = `${role.benchLabel} — ${round.speakers[role.id] ?? '(not yet assigned)'}`;
        opt.disabled = !round.speakers[role.id];
        if (round.replyAssignments[replyRole.id] === role.id) opt.selected = true;
        select.appendChild(opt);
      }
      select.addEventListener('change', async () => {
        if (!select.value) return;
        try {
          const updated = await api.assignReply(round.id, { replyRoleId: replyRole.id, deliveredByRoleId: select.value });
          setState({ round: updated });
          refreshTimer(updated);
        } catch (err) {
          window.veridictToast?.(err.message || 'Could not assign reply speaker.', 'error');
        }
      });
      replyListEl.appendChild(row);
    }
  }

  function refreshTimer(latestRound) {
    timerSlot.innerHTML = '';
    renderTimerPoi(timerSlot, { round: latestRound, format });
  }
  refreshTimer(round);

  goNext.disabled = false;
  goNext.onclick = () => document.dispatchEvent(new CustomEvent('veridict:advance'));
}
