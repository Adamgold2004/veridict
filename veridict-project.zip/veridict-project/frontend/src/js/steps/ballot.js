import { api } from '../lib/api.js';
import { setState, state } from '../lib/state.js';
import { renderScoreCard } from '../components/scoreInput.js';
import { renderRankingSelector } from '../components/rankingSelector.js';

export async function renderBallot(container, { goNext }) {
  if (!state.round) {
    container.innerHTML = '<p class="text-muted">Complete Setup first.</p>';
    goNext.disabled = true;
    return;
  }
  goNext.style.display = 'none'; // Ballot is the last step — no "Next".

  let round = await api.getRound(state.roundId);
  const format = state.format ?? (await api.getFormat(round.formatId));
  setState({ round, format });

  container.innerHTML = `
    <div class="step-ballot">
      <div class="lock-status">
        <span class="status-badge status-${round.status}">${round.status.toUpperCase()}</span>
        <button class="btn btn-ghost btn-sm" data-action="toggle-guide">View scoring guide</button>
        <button class="btn btn-ghost btn-sm" data-action="reopen" style="display:none;">Reopen ballot</button>
      </div>
      <div class="scoring-guide-slot"></div>

      <div class="result-control">
        <h3>Result</h3>
        <div class="result-slot"></div>
      </div>

      <h3>Scores</h3>
      <div class="scores-slot"></div>

      <h3 style="margin-top:20px;">Reason for decision</h3>
      <div class="field">
        <textarea class="reason-input" placeholder="Explain the decision — what won the round and why."></textarea>
      </div>

      <div class="alert-slot"></div>

      <div class="ballot-actions">
        <button class="btn btn-primary" data-action="submit">
          <svg class="lock-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="5" y="11" width="14" height="9" rx="2"></rect>
            <path class="lock-shackle" d="M8 11V8a4 4 0 0 1 8 0v3"></path>
          </svg>
          Submit ballot
        </button>
      </div>
    </div>
  `;

  const guideSlot = container.querySelector('.scoring-guide-slot');
  container.querySelector('[data-action="toggle-guide"]').addEventListener('click', async () => {
    if (guideSlot.childElementCount) {
      guideSlot.innerHTML = '';
      return;
    }
    const guide = await api.getScoringGuide(format.id);
    const wrap = document.createElement('div');
    wrap.className = 'info-card scoring-guide';
    wrap.innerHTML = renderGuideHtml(guide);
    guideSlot.appendChild(wrap);
  });

  // --- Result control ---
  const resultSlot = container.querySelector('.result-slot');
  if (format.rankingType === 'single-winner') {
    const wrap = document.createElement('div');
    wrap.className = 'winner-options';
    for (const side of format.sides) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `winner-option${round.winnerSide === side.key ? ' is-selected' : ''}`;
      btn.textContent = side.label;
      btn.addEventListener('click', async () => {
        round = await api.setResult(round.id, { winnerSide: side.key });
        setState({ round });
        [...wrap.children].forEach((c) => c.classList.remove('is-selected'));
        btn.classList.add('is-selected');
      });
      wrap.appendChild(btn);
    }
    resultSlot.appendChild(wrap);
  } else {
    renderRankingSelector(resultSlot, format.sides, round.ranking, async (ranking, isComplete) => {
      if (!isComplete) return;
      round = await api.setResult(round.id, { ranking });
      setState({ round });
    });
  }

  // --- Scores ---
  const scoresSlot = container.querySelector('.scores-slot');
  for (const role of format.roles) {
    if (!round.speakers[role.id]) continue;
    renderScoreCard(scoresSlot, {
      round,
      format,
      role,
      speakerName: round.speakers[role.id],
      existingScore: round.scores[role.id],
      onSaved: (updated) => {
        round = updated;
        setState({ round });
      },
    });
  }
  if (format.roles.some((r) => !round.speakers[r.id])) {
    const note = document.createElement('p');
    note.className = 'text-sm text-muted';
    note.textContent = 'Assign every speaker in the Speeches step to score them here.';
    scoresSlot.appendChild(note);
  }

  // --- Reason ---
  const reasonInput = container.querySelector('.reason-input');
  reasonInput.value = round.reasonForDecision ?? '';
  reasonInput.addEventListener('blur', async () => {
    round = await api.setReason(round.id, { reasonForDecision: reasonInput.value });
    setState({ round });
  });

  applyLockState(container, round);

  container.querySelector('[data-action="reopen"]').addEventListener('click', async () => {
    round = await api.reopenRound(round.id);
    setState({ round });
    animateLock(container, false);
    applyLockState(container, round);
  });

  container.querySelector('[data-action="submit"]').addEventListener('click', async () => {
    const alertSlot = container.querySelector('.alert-slot');
    alertSlot.innerHTML = '';
    try {
      round = await api.submitBallot(round.id);
      setState({ round });
      animateLock(container, true);
      applyLockState(container, round);
      alertSlot.innerHTML = `<div class="alert alert-success">Ballot submitted and locked.</div>`;
    } catch (err) {
      const errors = err.details?.errors ?? [err.message];
      const lowPointWin = err.details?.lowPointWin;
      let html = `<div class="alert alert-error"><strong>Ballot cannot be submitted.</strong><ul>${errors
        .map((e) => `<li>${escapeHtml(e)}</li>`)
        .join('')}</ul></div>`;
      alertSlot.innerHTML = html;

      if (lowPointWin) {
        const confirmWrap = document.createElement('div');
        confirmWrap.className = 'alert alert-warning';
        confirmWrap.innerHTML = `
          This is a low-point win — ${lowPointWin.winnerSide} (${lowPointWin.winnerTotal}) has fewer speaker points
          than ${lowPointWin.opponentSide} (${lowPointWin.opponentTotal}). Please confirm this is intentional.
          <div style="margin-top:8px;"><button class="btn btn-sm btn-primary" data-action="confirm-lpw">Confirm low-point win</button></div>
        `;
        alertSlot.appendChild(confirmWrap);
        confirmWrap.querySelector('[data-action="confirm-lpw"]').addEventListener('click', async () => {
          round = await api.confirmLowPointWin(round.id);
          setState({ round });
          window.veridictToast?.('Low-point win confirmed. Try submitting again.', 'success');
        });
      }
    }
  });
}

function applyLockState(container, round) {
  const locked = round.status === 'submitted';
  container.querySelectorAll('input, textarea, select, button').forEach((el) => {
    if (el.dataset.action === 'reopen' || el.dataset.action === 'toggle-guide') return;
    el.disabled = locked;
  });
  container.querySelector('[data-action="reopen"]').style.display = locked ? 'inline-flex' : 'none';
  const badge = container.querySelector('.status-badge');
  badge.className = `status-badge status-${round.status}`;
  badge.textContent = round.status.toUpperCase();
}

function animateLock(container, locking) {
  const shackle = container.querySelector('.lock-shackle');
  if (!shackle) return;
  if (window.gsap) {
    window.gsap.to(shackle, {
      rotate: locking ? 0 : -25,
      transformOrigin: '8px 8px',
      duration: 0.35,
      ease: 'back.out(2)',
    });
  }
}

function renderGuideHtml(guide) {
  const section = (title, rows) =>
    rows?.length
      ? `<div><h3>${title}</h3>${rows
          .map((r) => `<div class="band-row"><span class="band-range mono">${r.band}</span><span>${escapeHtml(r.descriptor)}</span></div>`)
          .join('')}</div>`
      : '';
  return section('Content', guide.content) + section('Style', guide.style) + section('Strategy', guide.strategy);
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}
