import { state, setState, subscribe } from './lib/state.js';
import { renderSetup } from './steps/setup.js';
import { renderSpeeches } from './steps/speeches.js';
import { renderAiSuggestion } from './steps/aiSuggestion.js';
import { renderBallot } from './steps/ballot.js';

const STEPS = [
  { key: 'setup', label: 'Setup', render: renderSetup },
  { key: 'speeches', label: 'Speeches', render: renderSpeeches },
  { key: 'ai', label: 'AI Suggestion', render: renderAiSuggestion },
  { key: 'ballot', label: 'Ballot', render: renderBallot },
];

const app = document.getElementById('app');
app.innerHTML = `
  <div class="app-shell">
    <header class="app-header">
      <div class="brand">
        <h1>Veridict</h1>
        <span class="brand-tag">debate adjudication, correct by construction</span>
      </div>
    </header>
    <nav class="wizard-steps"></nav>
    <section class="wizard-step"></section>
    <div class="wizard-nav">
      <button class="btn" data-action="back">Back</button>
      <button class="btn btn-primary" data-action="next">Next</button>
    </div>
  </div>
  <div class="toast-root" style="position:fixed;bottom:20px;right:20px;display:flex;flex-direction:column;gap:8px;z-index:50;"></div>
`;

const pillsEl = app.querySelector('.wizard-steps');
const stepEl = app.querySelector('.wizard-step');
const backBtn = app.querySelector('[data-action="back"]');
const nextBtn = app.querySelector('[data-action="next"]');
const toastRoot = app.querySelector('.toast-root');

window.veridictToast = function toast(message, kind = 'error') {
  const el = document.createElement('div');
  el.className = `alert alert-${kind === 'error' ? 'error' : kind}`;
  el.style.maxWidth = '320px';
  el.style.marginBottom = '0';
  el.textContent = message;
  toastRoot.appendChild(el);
  if (window.gsap) {
    window.gsap.fromTo(el, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.25 });
  }
  setTimeout(() => {
    if (window.gsap) {
      window.gsap.to(el, { opacity: 0, y: -10, duration: 0.25, onComplete: () => el.remove() });
    } else {
      el.remove();
    }
  }, 4000);
};

function renderPills() {
  pillsEl.innerHTML = '';
  STEPS.forEach((step, i) => {
    const pill = document.createElement('button');
    pill.type = 'button';
    pill.className = `wizard-step-pill${i === state.step ? ' is-active' : ''}${i < state.step ? ' is-complete' : ''}`;
    pill.textContent = `${i + 1}. ${step.label}`;
    pill.disabled = i > state.step && !state.round; // can't skip ahead before a round exists
    pill.addEventListener('click', () => {
      if (i <= state.step || state.round) goToStep(i, i > state.step ? 1 : -1);
    });
    pillsEl.appendChild(pill);
  });
}

async function goToStep(index, direction = 1) {
  const step = STEPS[index];
  if (!step) return;

  nextBtn.style.display = 'inline-flex';
  nextBtn.disabled = true;
  backBtn.disabled = index === 0;

  const transition = () => {
    setState({ step: index });
    renderPills();
    return step.render(stepEl, { goNext: nextBtn });
  };

  if (window.gsap) {
    const tl = window.gsap.timeline();
    tl.to(stepEl, { opacity: 0, x: direction > 0 ? -16 : 16, duration: 0.15, ease: 'power1.in' }).call(async () => {
      await transition();
      window.gsap.fromTo(stepEl, { opacity: 0, x: direction > 0 ? 16 : -16 }, { opacity: 1, x: 0, duration: 0.25, ease: 'power1.out' });
    });
  } else {
    await transition();
  }
}

backBtn.addEventListener('click', () => {
  if (state.step > 0) goToStep(state.step - 1, -1);
});
nextBtn.addEventListener('click', () => {
  // Individual step modules attach their own onclick that runs validation/API
  // calls first, then dispatch 'veridict:advance'. This top-level listener is
  // just the fallback wiring point; steps override nextBtn.onclick directly.
});

document.addEventListener('veridict:advance', () => {
  if (state.step < STEPS.length - 1) goToStep(state.step + 1, 1);
});

subscribe(() => renderPills());

goToStep(0, 1);
